% Given system parameters
Mp = 0.024;
Mr = 0.095;
b1 = 0.0005;
b2 = 0.0001;
Lp = 0.129;
Lr = 0.085;
g = 9.81;
Km = 0.042
Rm = 8.4;

% Compute derived parameters
Jp = Mp * (Lp^2) / 3;
Jr = Mr * (Lr^2) / 3;
l = Lp / 2;
J0 = 5.7198e-5 + Mp * (Lr^2);
J2 = 3.3185e-5 + Mp * (Lp / 2)^2;
Jt =J0*J2 - (Mp^2)*(Lr^2)*(Lp/2)^2 ; 

% State-space matrices
A = [0, 0, 1, 0; 0, 0, 0, 1; 0, (g * Mp^2 * Lp^2 * Lr) / 4*Jt, - (b1 * J2 + (Km^2 * J2 / Rm)) / Jt, - (b2 * Mp * Lp * Lr) / 2*Jt; 0, (g * Mp * Lp * J0) / Jt, - (((b1 * Mp * Lp * Lr)/2) + (Km^2 * Mp * Lp * Lr)/(2*Rm)) / Jt, - (b2 * J0) / Jt];
B = [0; 0; (J2 * Km) / (Jt * Rm); (Km * Mp * Lp * Lr) / (2 * Jt * Rm)];
C = [1, 0, 0, 0; 0, 1, 0, 0];
D = [0; 0];

disp(A);
disp(B);

% Check Controllability
Controllability = [B A*B A^2*B A^3*B];
rank_C = rank(Controllability);
if rank_C == 4
disp('The system is Controllable.');
disp(rank_C);
else
disp('The system is NOT Controllable.');
end
% Check Observability
Observability = [C; C*A; C*A^2; C*A^3];
rank_O = rank(Observability);
if rank_O == 4
disp('The system is Observable.');
disp(rank_O);
else
disp('The system is NOT Observable.');
end

% Design Specification for the Controller

percentOvershoot = 10; % Desired percent overshoot
bandwidthHz= 15;% Desired closed-loop bandwidth (Hz
phaseMarginDeg= 45; % Desired phase margin



dampingRatio = -log(10/100) / sqrt(pi^2 + log(10/100)^2); % Damping ratio

wn = bandwidthHz / sqrt(1 - 2*dampingRatio^2 + sqrt(4*dampingRatio^4 - 4* dampingRatio^2 + 2));% Natural frequency based on bandwidth

% Dominant poles
polel = -dampingRatio*wn + 1i*wn* sqrt(1 - dampingRatio^2);
pole2 = -dampingRatio*wn - 1i*wn* sqrt(1 - dampingRatio^2);

% Additional poles placed left of dominant poles for fast convergence
pole3= -wn + 1i * 0.5 * wn;
pole4 = -wn - 1i * 0.5 * wn;

% Desired closed-loop pole set
desiredPoles = [polel, pole2, pole3, pole4];
disp('DesiredPoles = ');
disp(desiredPoles);

% Characteristic polynomial of desired poles
charPoly = poly(desiredPoles);
normPoly = charPoly / charPoly(1);

% Matrix method for pole placement
I4 = eye(4);
Qa = A^4*normPoly(1) + A^3 *normPoly(2) + A^2 *normPoly(3) + A*normPoly(4) + I4 *normPoly(5);
K = [0 0 0 1]*inv(Controllability) * Qa;
disp('K=');
disp(K);

% Observer design with shifted poles (faster dynamics)
observerPoles = desiredPoles - 800;
L = place (A', C', observerPoles)';
disp('L=');
disp(L);